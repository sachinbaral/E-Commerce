package com.srh.ecommerce.view;

public class AdminSearch {
	
	private String userName;
	private String companyName;
	
	
	public String getUserName() {
		return userName;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
		
	

}
